import urllib.request
import socket
import ssl
import time
import json 
import ipaddress
import sys
from statistics import mean
from azure.iot.device import IoTHubDeviceClient, Message
# sys.path.insert(0, 'C:\Users\sujith.thota\Downloads\python-prototype-app\python-prototype-app\common')
# from system_metrics import SystemMetrics

class DownLink:
    def __init__(self, url, test_duration, buffer_size, delta):
        self.url = url
        self.test_duration = test_duration
        self.buffer_size = buffer_size * 1024
        self.delta = delta

    def run(self):
        start_time, ttfb, ssl_handshake_time = self._initialize_variables()

        throughput_collection = []
        matrics = []
        data_transferred = 0
        last_measurement_time = start_time

        req = urllib.request.Request(self.url, headers={'User-Agent': self._get_user_agent()})

        hostname, ip_address = self._get_hostname_and_ip()
        context, start_ssl_time = self._perform_ssl_handshake(req)

        self._read_initial_response(req, context)

        while time.time() - start_time < self.test_duration:
            response, chunk = self._download_chunk(req)

            if ttfb is None:
                ttfb = time.time() - start_time

            data_transferred = self._update_data_counters(
                data_transferred, chunk, start_time
            )

            if time.time() - start_time > self.test_duration:
                break

            throughput_collection, delta_count, last_measurement_time = self._measure_throughput(
                throughput_collection, data_transferred, start_time, last_measurement_time
            )

            if time.time() - start_time > self.test_duration:
                break

            chunk = response.read(self.buffer_size)

        duration = time.time() - start_time
        download_speed = self._calculate_download_speed(data_transferred, duration)

        Key_to_check='Throughput'
        values_for_key=[d[Key_to_check] for d in throughput_collection]

        avg_download=self._average_downlink(values_for_key)

        # max_down=max(values_for_key)

        ipv = self.ip_version(ip_address)
        content_t = self.content_type(self.url)
        trp = self._throughput_rate(throughput_collection)
        results = self._create_results(download_speed, ssl_handshake_time, ttfb, data_transferred,
                                       ip_address, start_time, duration,
                                       throughput_collection,ipv,content_t,avg_download,trp)

        self._print_results(results)


    

    def _average_downlink(self,values):
        average_dow=mean(values)
        return average_dow

    def _initialize_variables(self):
        start_time = time.time()
        ttfb = None
        ssl_handshake_time = None
        return start_time, ttfb, ssl_handshake_time

    def _perform_ssl_handshake(self,req):
        context = ssl._create_unverified_context()
        start_ssl_time = time.time()
        with urllib.request.urlopen(req, context=context) as response:
            response.read(1)
        ssl_handshake_time = time.time() - start_ssl_time
        return context, start_ssl_time

    def _get_user_agent(self):
        return 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3'

    def _read_initial_response(self, req, context):
        with urllib.request.urlopen(req, context=context) as response:
            response.read(1)

    def _download_chunk(self, req):
        context = ssl._create_unverified_context()
        response = urllib.request.urlopen(req,context=context)
        chunk = response.read(self.buffer_size)
        return response, chunk

    def _update_data_counters(self, data_transferred, chunk, start_time):
        data_transferred += len(chunk)
        return data_transferred
    
    def ip_version(self,ip_add):
        ip_ver = ipaddress.ip_address(str(ip_add))
        #print(type(ip_ver.version))
        if ip_ver.version == 4:
            return 'IPv4'
        elif ip_ver.version == 6:
            return 'IPv6'
        else:
            return 'Unknown'
        
    
    
    def content_type(self,st):
        context = ssl._create_unverified_context()
        with urllib.request.urlopen(st,context=context) as response:
            info = response.info()
            return info.get_content_type()
        
    def _get_hostname_and_ip(self):
        hostname = self.url.split('//')[1].split('/')[0] #speed.hetzner.de
        ip_address = socket.gethostbyname(hostname) #88.198.248.254
        return hostname, ip_address
    
    def _throughput_rate(self,throughput_collection):
        key2 = 'time'
        time_between = [k[key2] for k in throughput_collection]

        key3 = 'bytes_transferred'
        bytes_between = [j[key3] for j in throughput_collection]

        listT = []

        for i in range(0,len(time_between)):
            if i == 0:
                listT.append((bytes_between[i] - i)/(time_between[i]-i))
            else:
                listT.append((bytes_between[i] - bytes_between[i-1])/(time_between[i] - time_between[i-1] ))

        
        return listT
            



    def _measure_throughput(self, throughput_collection, data_transferred, start_time, last_measurement_time):
        if time.time() - last_measurement_time >= self.delta:
            throughput = data_transferred / (time.time() - start_time)
            throughput_collection.append({
                'delta': len(throughput_collection),
                'time': time.time() - start_time,
                'bytes_transferred': data_transferred,
                'Throughput': throughput
            })
            # matrics.append()
            last_measurement_time = time.time()
        return throughput_collection, len(throughput_collection), last_measurement_time

    def _calculate_download_speed(self, data_transferred, duration):
        return data_transferred / duration

    def _create_results(self, download_speed, ssl_handshake_time, ttfb, data_transferred,
                        ip_address, start_time, duration, throughput_collection,ipv,content_t,avg_download,trp):
        
        results = {
            'info': {
                'download_speed': download_speed,
                'average download speed':avg_download,
                'total_data_transfer': data_transferred,
                'server_host': self.url,
                'content type':content_t,
                'server_ip_address': ip_address,
                'iP version': ipv,
                'duration': duration,
                'timestamp': start_time,
                'throughput_measurements': throughput_collection,
                'throughput_rate at measurement points':trp
            }
        }
        return results

    def _print_results(self, results):
        conn_str = "HostName=cpelanprobeiothub.azure-devices.net;DeviceId=testdev;SharedAccessKey=pCBXq7CW5UKuvhi4WKcTns778oyRaIr/59zu5DNvkOk="

        # Create an IoT Hub client
        client = IoTHubDeviceClient.create_from_connection_string(conn_str)

        # print(results['info']['download_speed'])

        # Define telemetry data as a Python dictionary
        telemetry_data = {
            "DeviceID": results['info']['download_speed'],
            "ModuleID": results['info']['server_ip_address'],
            "DeviceLocation": results['info']['iP version']
        }
        json_data = json.dumps(telemetry_data)

        # Create a telemetry message using the JSON data
        message = Message(json_data)
       
    
        # Send the telemetry message to IoT Hub
        client.send_message(message)
        print("Message sent")

        # Close the client
        client.shutdown()


if __name__ == '__main__':
    downlink = DownLink("https://ash-speed.hetzner.com/1GB.bin", 20, 1024,2)
    downlink.run()
    


